import React, { useState } from 'react';
import { Button, Modal, ListGroup } from 'react-bootstrap';
import axios from 'axios';
import ReactMarkdown from 'react-markdown';

const SupportPage = ({ onBackClick }) => {
  const [inputText, setInputText] = useState('');
  const [modalShow, setModalShow] = useState(false);
  const [chatHistory, setChatHistory] = useState([]); // List to store query and response
  const [loading, setLoading] = useState(false);
  const [responseText, setResponseText] = useState(''); // Store the response text separately
  const [previousResponse, setPreviousResponse] = useState(''); // Store the previous response

  const handleChange = (e) => {
    setInputText(e.target.value);
  };

  // Function to submit query and show modal
  const handleModalShow = async () => {
    if (!inputText.trim()) return; // Prevent empty submissions
    setModalShow(true);
    setLoading(true);

    try {
      const response = await axios.post('http://localhost:5000/support', {
        text: inputText,
        text2: previousResponse || 'No previous response', // Pass previous response
      });
      setResponseText(response.data.responseText); // Update response text in modal
    } catch (error) {
      console.error('Error fetching response:', error);
      setResponseText('Error generating support response.');
    } finally {
      setLoading(false);
    }
  };

  // Accept suggestion and add to chat history
  const handleAcceptSuggestion = () => {
    const newChatItem = {
      query: inputText,
      response: responseText,
    };
    setChatHistory((prevChatHistory) => [...prevChatHistory, newChatItem]); // Add to chat history
    setPreviousResponse(responseText); // Set previous response for next query
    setInputText(''); // Clear input field after accepting
    setModalShow(false); // Close the modal
  };

  // Regenerate the response
  const handleRegenerate = async () => {
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/support', {
        text: inputText,
        text2: previousResponse || 'No previous response',
      });
      setResponseText(response.data.responseText); // Replace with regenerated response
    } catch (error) {
      console.error('Error regenerating response:', error);
      setResponseText('Error generating support response.');
    } finally {
      setLoading(false);
    }
  };

  // Reset the chat history
  const handleReset = () => {
    setChatHistory([]); // Clear the chat history
    setInputText(''); // Clear the input field
    setResponseText(''); // Clear the response text
    setPreviousResponse(''); // Clear the previous response
  };

  const handleModalClose = () => {
    setModalShow(false);
  };

  return (
    <div className="support-page">
      <Button variant="link" onClick={onBackClick} className="back-btn">
        &larr; Back
      </Button>

      <h2>Ansh - Support Jam</h2>

      {/* Chat History Section */}
      <div className="chat-history mb-4">
        <ListGroup>
          {chatHistory.map((item, index) => (
            <ListGroup.Item key={index}>
              <strong>Query:</strong> {item.query}
              <div>
                <strong>Response:</strong>
                <div className="markdown-container">
                  <ReactMarkdown>{item.response}</ReactMarkdown>
                </div>
              </div>
            </ListGroup.Item>
          ))}
        </ListGroup>
      </div>

      {/* Input and Submission Section */}
      <div className="d-flex flex-column align-items-start">
        <textarea
          value={inputText}
          onChange={handleChange}
          placeholder="Enter your query or issue..."
          className="form-control"
          rows="5"
        />
        <Button variant="primary" onClick={handleModalShow} className="mt-3">
          <i className="fas fa-edit"></i> Submit Query
        </Button>
        <Button variant="danger" onClick={handleReset} className="mt-3">
          Reset Chat
        </Button>
      </div>

      {/* Modal for showing the response */}
      <Modal show={modalShow} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>Support Response</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="form-group">
            <label>Your Query:</label>
            <textarea value={inputText} readOnly className="form-control" rows="3" />
          </div>
          <div className="form-group">
            <label>Response:</label>
            {loading ? (
              <div>Loading...</div>
            ) : (
              <div className="markdown-container">
                <ReactMarkdown>{responseText}</ReactMarkdown>
              </div>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAcceptSuggestion} disabled={loading}>
            Accept Suggestion
          </Button>
          <Button variant="warning" onClick={handleRegenerate} disabled={loading}>
            Regenerate
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default SupportPage;
